/* Akshay Pandya - Hwk2JML */
public class Hwk2 
{
	 private /*@ spec_public @*/ int arr[] ; 
		
     private /*@ spec_public @*/ int i;
     private /*@ spec_public @*/ int j;
     private /*@ spec_public @*/ int k;
      
     
     //@ public invariant (\forall  int n; i <= n  &&   n <= j;  arr[n] == 0);
     
     //@ public invariant (\exists int n; n <= i && j <= n; arr[n] == 0);
     
     //@ public invariant (\exists int n,m; 0 <= n && 0 <= m && n <= k-1 && m <= k-1; arr[n] == 0 && arr[m] == 0 && m!=n);
     
     //@ public invariant (\exists int a,b; 0 <= a && a <= k-1 && 0 <= b && b <= k-1;(\sum int x; 0 <= x && x <= k-1;arr[x] ) - arr[a] == (\sum int x; 0 <= x && x <= k-1;arr[x] ) - arr[b] && (\forall int y; 0 <= y && y <= k-1;(\sum int x; 0 <= x && x <= k-1; arr[x]) - arr[y] == (\sum int x; 0 <= x && x <= k-1; arr[x]) ==> y == a || y == b)); 
  
     
     
     
}

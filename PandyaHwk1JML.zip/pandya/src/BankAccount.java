/* Akshay Pandya - Hwk2JML */

public class BankAccount
 {
 
      public static final int MAX_BALANCE = 5000; 
      public static final int  RATE = 3;
      private /*@ spec_public @*/ int balance;

      private /*@ spec_public @*/ boolean isLocked = false; 
	  
    
 
     //@ public invariant balance >= 0 && balance <= MAX_BALANCE;
 
 
    //@ assignable balance;
    //@ ensures balance == 0;
    public void BankAccount()
    {
        this.balance = 0;
    }

    
 
    //@ requires 0 < amount && balance + amount <= MAX_BALANCE ;
    //@ assignable balance;
    //@ ensures balance == \old(balance) + amount;
    public void deposit(final int amount)
    {
        this.balance += amount;
    }
 
 
    //@ requires 0 < amount && amount <= balance;
    //@ assignable balance;
    //@ ensures balance == \old(balance) - amount;
    public void withdraw(final int amount)
    {
        this.balance -= amount;
    }

    //@ requires 0 < amount &&  amount + balance <= MAX_BALANCE; 
    //@ requires amount <= other.balance  ;
    //@ assignable balance, other.balance;
    // We Don't need to ensure the balance as it is checked in the deposit and withdraw events.
/*  //@ ensures balance == \old(balance) + amount ;
    //@ ensures other.balance == \old(other.balance) - amount;		*/
    public void transferTo(BankAccount other, final int amount) 
    {   
        other.withdraw(amount);
        this.deposit(amount);
     }
    
    //@ requires 0 < amount &&  amount + other.balance <= MAX_BALANCE; 
    //@ requires amount <= balance  ;
    //@ assignable balance, other.balance;
    // We Don't need to ensure the balance as it is checked in the deposit and withdraw events.
/*  //@ ensures other.balance == \old(other.balance) + amount ;
    //@ ensures balance == \old(balance) - amount;					*/
    public void transferFrom(BankAccount other, final int amount) 
    {   
    	this.withdraw(amount);
        other.deposit(amount);    
    }
    
    //@ requires  (100*balance + (balance*RATE)) <= 100*MAX_BALANCE;
    //@ assignable balance;
    void creditSomeMoney()
    {
        int temp = RATE;
        balance = balance + temp;
    }
    
    //@ ensures isLocked == true;
    public void lockAccount()
    {
        this.isLocked = true;
    }


	
    //@   requires !isLocked;
    //@   ensures \result == balance;
    //@ also
    //@   requires isLocked;
    //@   signals_only Exception;
    public /*@ pure @*/ int getBalance() throws Exception
    {
        if (!this.isLocked)
        {
                return this.balance;
        }
        else
        {
                throw new Exception();
        }
    }
 }
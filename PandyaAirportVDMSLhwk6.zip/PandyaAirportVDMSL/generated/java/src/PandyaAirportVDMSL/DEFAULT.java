package PandyaAirportVDMSL;

import org.overture.codegen.runtime.*;

import java.util.*;


@SuppressWarnings("all")
final public class DEFAULT {
    public static final Number max = 10L;
    private static AirportX AirportX = new AirportX(SetUtil.set(),
            SetUtil.set(), SeqUtil.seq());

    private DEFAULT() {
    }

    public static Number totalAircraftsQueue() {
        throw new UnsupportedOperationException();
    }

    public static void allowCircling(final Token AircraftArrive) {
        throw new UnsupportedOperationException();
    }

    public static void allowLand(final Token AircraftLand) {
        throw new UnsupportedOperationException();
    }

    public static void givePermission(final Token AircraftIn) {
        throw new UnsupportedOperationException();
    }

    public static void recordDeparture(final Token AircraftOut) {
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return "DEFAULT{" + "max = " + Utils.toString(max) + ", AirportX := " +
        Utils.toString(AirportX) + "}";
    }

    public static class AirportX implements Record {
        public VDMSet permitted;
        public VDMSet landed;
        public VDMSeq circling;

        public AirportX(final VDMSet _permitted, final VDMSet _landed,
            final VDMSeq _circling) {
            permitted = (_permitted != null) ? Utils.copy(_permitted) : null;
            landed = (_landed != null) ? Utils.copy(_landed) : null;
            circling = (_circling != null) ? Utils.copy(_circling) : null;
        }

        public boolean equals(final Object obj) {
            if (!(obj instanceof AirportX)) {
                return false;
            }

            AirportX other = ((AirportX) obj);

            return (Utils.equals(permitted, other.permitted)) &&
            (Utils.equals(landed, other.landed)) &&
            (Utils.equals(circling, other.circling));
        }

        public int hashCode() {
            return Utils.hashCode(permitted, landed, circling);
        }

        public AirportX copy() {
            return new AirportX(permitted, landed, circling);
        }

        public String toString() {
            return "mk_DEFAULT`AirportX" +
            Utils.formatFields(permitted, landed, circling);
        }
    }
}
